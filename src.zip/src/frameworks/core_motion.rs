/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
//! The Core Motion framework.
//!
//! Per Apple's CoreMotion Framework Reference (iOS 4.0+, available since 2.0
//! as UIAccelerometer):
//!
//! - CMMotionManager: The gateway object for accelerometer, gyroscope, and
//!   device-motion services.
//! - CMAccelerometerData: Contains a single accelerometer reading
//!   (CMAcceleration with x, y, z in G-force units).
//! - CMGyroData: Contains a single gyroscope reading (CMRotationRate with
//!   x, y, z in radians/second).
//! - CMDeviceMotion: Contains processed device-motion data combining
//!   accelerometer + gyroscope: attitude, rotationRate, gravity,
//!   userAcceleration.
//! - CMAcceleration: struct { x: f64, y: f64, z: f64 }
//! - CMRotationRate: struct { x: f64, y: f64, z: f64 }
//!
//! This implementation integrates with the SDL sensor subsystem (via the
//! window's accelerometer reading) to provide real accelerometer data when
//! available, and falls back to simulated gravity (0, 0, -1) otherwise.

use crate::abi::{impl_GuestRet_for_large_struct, GuestArg};
use crate::dyld::HostDylib;
use crate::objc::{
    autorelease, id, msg_class, nil, objc_classes, ClassExports, HostObject, NSZonePtr,
};
use crate::Environment;
use std::time::Instant;

pub const DYLIB: HostDylib = HostDylib {
    path: "/System/Library/Frameworks/CoreMotion.framework/CoreMotion",
    aliases: &[],
    class_exports: &[CLASSES],
    constant_exports: &[],
    function_exports: &[],
};

// =============================================================================
// Host object types
// =============================================================================

/// Per Apple docs: CMAcceleration is a structure with x, y, z fields
/// representing acceleration in G-force units along each axis.
/// iPhone coordinate system:
///   x: lateral (positive = right)
///   y: longitudinal (positive = up toward top of device)
///   z: perpendicular to screen (positive = toward user)
/// When device is flat on table face-up: x=0, y=0, z=-1 (gravity pulling down)
#[derive(Clone, Copy, Debug, Default, PartialEq)]
#[repr(C, packed)]
struct CMAcceleration {
    x: f64,
    y: f64,
    z: f64,
}
unsafe impl crate::mem::SafeRead for CMAcceleration {}
impl_GuestRet_for_large_struct!(CMAcceleration);
impl GuestArg for CMAcceleration {
    const REG_COUNT: usize = 6;
    fn from_regs(regs: &[u32]) -> Self {
        CMAcceleration {
            x: f64::from_regs(&regs[0..2]),
            y: f64::from_regs(&regs[2..4]),
            z: f64::from_regs(&regs[4..6]),
        }
    }
    fn to_regs(self, regs: &mut [u32]) {
        let (x, y, z) = (self.x, self.y, self.z);
        x.to_regs(&mut regs[0..2]);
        y.to_regs(&mut regs[2..4]);
        z.to_regs(&mut regs[4..6]);
    }
}

/// Per Apple docs: CMRotationRate in radians per second around each axis.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
#[repr(C, packed)]
struct CMRotationRate {
    x: f64,
    y: f64,
    z: f64,
}
unsafe impl crate::mem::SafeRead for CMRotationRate {}
impl_GuestRet_for_large_struct!(CMRotationRate);
impl GuestArg for CMRotationRate {
    const REG_COUNT: usize = 6;
    fn from_regs(regs: &[u32]) -> Self {
        CMRotationRate {
            x: f64::from_regs(&regs[0..2]),
            y: f64::from_regs(&regs[2..4]),
            z: f64::from_regs(&regs[4..6]),
        }
    }
    fn to_regs(self, regs: &mut [u32]) {
        let (x, y, z) = (self.x, self.y, self.z);
        x.to_regs(&mut regs[0..2]);
        y.to_regs(&mut regs[2..4]);
        z.to_regs(&mut regs[4..6]);
    }
}

#[derive(Default)]
struct CMMotionManagerHostObject {
    accelerometer_update_interval: f64,
    gyro_update_interval: f64,
    device_motion_update_interval: f64,
    accelerometer_active: bool,
    gyro_active: bool,
    device_motion_active: bool,
    /// Cached last accelerometer reading
    last_acceleration: CMAcceleration,
    /// Timestamp of last accelerometer update
    last_accel_timestamp: f64,
    /// Reference time for computing timestamps. `None` only for the phantom
    /// fallback created via `Default::default()`; real motion managers
    /// allocated through `+alloc` always populate this with `Instant::now()`.
    start_time: Option<Instant>,
    /// Complementary attitude filter state (quaternion, learned gyro bias,
    /// low-passed gravity input). `None` until the first device-motion read.
    attitude_state: Option<MotionFilter>,
}
impl HostObject for CMMotionManagerHostObject {}

#[derive(Default)]
struct CMAccelerometerDataHostObject {
    acceleration: CMAcceleration,
    timestamp: f64,
}
impl HostObject for CMAccelerometerDataHostObject {}

#[derive(Default)]
struct CMGyroDataHostObject {
    rotation_rate: CMRotationRate,
    timestamp: f64,
}
impl HostObject for CMGyroDataHostObject {}

#[derive(Default)]
struct CMDeviceMotionHostObject {
    /// Gravity component of acceleration
    gravity: CMAcceleration,
    /// User-generated acceleration (total minus gravity)
    user_acceleration: CMAcceleration,
    /// Rotation rate
    rotation_rate: CMRotationRate,
    timestamp: f64,
    /// Attitude from the sensor-fusion filter (pitch/roll/yaw + quaternion).
    attitude: CMAttitude,
    quaternion: CMQuaternion,
}
impl HostObject for CMDeviceMotionHostObject {}

#[derive(Clone, Copy, Debug, Default)]
struct CMAttitude {
    roll: f64,
    pitch: f64,
    yaw: f64,
}

/// Per Apple docs: CMQuaternion is (x, y, z, w) as IEEE doubles. Rotation of
/// angle theta about the unit axis (x, y, z) is represented as
/// (x*sin(theta/2), y*sin(theta/2), z*sin(theta/2), cos(theta/2)).
#[derive(Clone, Copy, Debug, Default, PartialEq)]
#[repr(C, packed)]
struct CMQuaternion {
    x: f64,
    y: f64,
    z: f64,
    w: f64,
}
unsafe impl crate::mem::SafeRead for CMQuaternion {}
impl_GuestRet_for_large_struct!(CMQuaternion);
impl GuestArg for CMQuaternion {
    const REG_COUNT: usize = 8;
    fn from_regs(regs: &[u32]) -> Self {
        CMQuaternion {
            x: f64::from_regs(&regs[0..2]),
            y: f64::from_regs(&regs[2..4]),
            z: f64::from_regs(&regs[4..6]),
            w: f64::from_regs(&regs[6..8]),
        }
    }
    fn to_regs(self, regs: &mut [u32]) {
        let (x, y, z, w) = (self.x, self.y, self.z, self.w);
        x.to_regs(&mut regs[0..2]);
        y.to_regs(&mut regs[2..4]);
        z.to_regs(&mut regs[4..6]);
        w.to_regs(&mut regs[6..8]);
    }
}

#[derive(Default)]
struct CMAttitudeHostObject {
    attitude: CMAttitude,
    quaternion: CMQuaternion,
}
impl HostObject for CMAttitudeHostObject {}

/// Per Apple docs: CMRotationMatrix is the device attitude expressed as a 3x3
/// rotation matrix of IEEE doubles (row-major m11..m33).
#[derive(Clone, Copy, Debug, Default, PartialEq)]
#[repr(C, packed)]
struct CMRotationMatrix {
    m11: f64,
    m12: f64,
    m13: f64,
    m21: f64,
    m22: f64,
    m23: f64,
    m31: f64,
    m32: f64,
    m33: f64,
}
unsafe impl crate::mem::SafeRead for CMRotationMatrix {}
impl_GuestRet_for_large_struct!(CMRotationMatrix);
impl GuestArg for CMRotationMatrix {
    const REG_COUNT: usize = 18;
    fn from_regs(regs: &[u32]) -> Self {
        CMRotationMatrix {
            m11: f64::from_regs(&regs[0..2]),
            m12: f64::from_regs(&regs[2..4]),
            m13: f64::from_regs(&regs[4..6]),
            m21: f64::from_regs(&regs[6..8]),
            m22: f64::from_regs(&regs[8..10]),
            m23: f64::from_regs(&regs[10..12]),
            m31: f64::from_regs(&regs[12..14]),
            m32: f64::from_regs(&regs[14..16]),
            m33: f64::from_regs(&regs[16..18]),
        }
    }
    fn to_regs(self, regs: &mut [u32]) {
        self.m11.to_regs(&mut regs[0..2]);
        self.m12.to_regs(&mut regs[2..4]);
        self.m13.to_regs(&mut regs[4..6]);
        self.m21.to_regs(&mut regs[6..8]);
        self.m22.to_regs(&mut regs[8..10]);
        self.m23.to_regs(&mut regs[10..12]);
        self.m31.to_regs(&mut regs[12..14]);
        self.m32.to_regs(&mut regs[14..16]);
        self.m33.to_regs(&mut regs[16..18]);
    }
}

/// Standard quaternion -> rotation matrix conversion.
fn quat_to_rotation_matrix(q: (f64, f64, f64, f64)) -> CMRotationMatrix {
    let (x, y, z, w) = q;
    CMRotationMatrix {
        m11: 1.0 - 2.0 * (y * y + z * z),
        m12: 2.0 * (x * y - w * z),
        m13: 2.0 * (x * z + w * y),
        m21: 2.0 * (x * y + w * z),
        m22: 1.0 - 2.0 * (x * x + z * z),
        m23: 2.0 * (y * z - w * x),
        m31: 2.0 * (x * z - w * y),
        m32: 2.0 * (y * z + w * x),
        m33: 1.0 - 2.0 * (x * x + y * y),
    }
}

/// Tait-Bryan Z-Y-X decomposition with Apple's axis mapping (pitch about the
/// device x-axis, roll about the y-axis, yaw about the z-axis).
fn quat_to_apple_angles(q: (f64, f64, f64, f64)) -> (f64, f64, f64) {
    let (x, y, z, w) = q;
    let pitch = (2.0 * (w * x + y * z)).atan2(1.0 - 2.0 * (x * x + y * y));
    let roll = (2.0 * (w * y - z * x)).clamp(-1.0, 1.0).asin();
    let yaw = (2.0 * (w * z + x * y)).atan2(1.0 - 2.0 * (y * y + z * z));
    (pitch, roll, yaw)
}

// =============================================================================
// Helper: read real accelerometer data from SDL sensor via window
// =============================================================================

/// Attempts to read the current accelerometer from the SDL sensor subsystem.
/// Returns (x, y, z) in G-force units matching iOS coordinate convention,
/// or None if no sensor is available.
fn read_sdl_accelerometer(env: &Environment) -> Option<CMAcceleration> {
    // `Window::get_acceleration` already returns the real or simulated
    // accelerometer reading in iOS G-force units (it converts SDL's m/s^2 and
    // flips the sign internally), so we just forward those values.
    let window = env.window.as_ref()?;
    let (x, y, z) = window.get_acceleration(&env.options);
    Some(CMAcceleration {
        x: x as f64,
        y: y as f64,
        z: z as f64,
    })
}

/// Returns (x, y, z) in radians per second around the device axes, matching
/// CMRotationRate's frame and units, or None if the host has no usable
/// gyroscope sensor.
fn read_sdl_gyroscope(env: &Environment) -> Option<CMRotationRate> {
    // `Window::get_rotation_rate` already returns the host gyroscope reading
    // in radians per second in the same device frame CMRotationRate uses, so
    // we just forward those values.
    let window = env.window.as_ref()?;
    let (x, y, z) = window.get_rotation_rate()?;
    Some(CMRotationRate {
        x: x as f64,
        y: y as f64,
        z: z as f64,
    })
}

// =============================================================================
// Attitude estimation (complementary gyroscope + accelerometer filter)
//
// Earlier versions derived roll/pitch with atan2() directly from the raw
// gravity vector. That is mathematically correct, but ill-conditioned exactly
// in the way phones are held while gaming (held upright in landscape, where
// gravity's z component is near zero and tiny tilts swing the estimated
// angles up to the full +/-90 degrees — the camera "snaps to max" symptom).
// Apple's own deviceMotion comes from sensor fusion and behaves smoothly in
// those holds, so we do a miniature version of the same: integrate the
// gyroscope and continuously correct the estimate towards the measured
// gravity vector. Without a host gyroscope the correction alone applies,
// which still smooths the old atan2-behaviour.
// =============================================================================

/// Smallest angular step worth applying, to avoid normalising ~zero vectors.
const ATTITUDE_EPSILON: f64 = 1.0e-9;

/// Time constant of the low-pass filter applied to the accelerometer before
/// it may push the attitude around. Smartphones' accelerometers wobble by
/// +-0.02g even in a resting hand (and much more during normal handling);
/// feeding that straight into a strong gravity correction shows up as
/// visible camera jitter. The gravity anchor only needs the slow content.
const ATTITUDE_ACCEL_LPF_TAU: f64 = 0.15;

/// Time constant for learning the gyroscope bias while the device is
/// evidently stationary. Host gyroscopes delivered through SDL can carry a
/// constant offset large enough to spin a naive complementary filter away.
/// Bias learning still requires a steady accelerometer reading, and the
/// near-zero-rate guard prevents a deliberate slow turn from being learned
/// as sensor drift.
const ATTITUDE_BIAS_TAU: f64 = 2.0;
/// Bias learning is limited to near-zero angular rates so a deliberate slow
/// turn is not mistaken for sensor drift.
const ATTITUDE_BIAS_MAX_RATE: f64 = 0.025;

/// Gain [0..1] of the gravity correction applied per second of elapsed time
/// while the (smoothed) accelerometer reading looks trustworthy. The anchor
/// must stay assertive — when it was weakened in testing, gyroscope bias on
/// real devices made the estimate wander — while the low-passed input keeps
/// it from twitching.
const ATTITUDE_CORRECTION_PER_SEC: f64 = 6.0;
/// How far the measured acceleration magnitude may deviate from 1g before
/// the gravity correction is distrusted completely. When the device is
/// being shaken/accelerated, the accelerometer's reading is no longer
/// "gravity" — weighting it then would inject the user's linear shaking
/// into the orientation. Tested against the RAW magnitude.
const ATTITUDE_ACCEL_TRUST_BAND: f64 = 0.2;
/// Gyroscope integration is skipped for steps larger than this: beyond it a
/// stale rate sample would integrate garbage (e.g. after a suspended frame).
const ATTITUDE_MAX_GYRO_DT: f64 = 0.25;

#[inline]
fn vec_len(v: (f64, f64, f64)) -> f64 {
    (v.0 * v.0 + v.1 * v.1 + v.2 * v.2).sqrt()
}
#[inline]
fn vec_sub(a: (f64, f64, f64), b: (f64, f64, f64)) -> (f64, f64, f64) {
    (a.0 - b.0, a.1 - b.1, a.2 - b.2)
}
#[inline]
fn vec_lerp(a: (f64, f64, f64), b: (f64, f64, f64), t: f64) -> (f64, f64, f64) {
    (
        a.0 + (b.0 - a.0) * t,
        a.1 + (b.1 - a.1) * t,
        a.2 + (b.2 - a.2) * t,
    )
}

/// Complementary gyro+accelerometer attitude filter with long-lived state:
/// low-passed gravity input and a learned gyroscope bias.
struct MotionFilter {
    /// Attitude quaternion (x, y, z, w) expressing device orientation.
    q: (f64, f64, f64, f64),
    /// Timestamp of the previous step.
    last: Instant,
    /// Low-pass filtered accelerometer input (gravity reference).
    smoothed_accel: (f64, f64, f64),
    /// Gyroscope bias learned while the device is stationary.
    gyro_bias: (f64, f64, f64),
}

impl MotionFilter {
    /// Initialise from the first accelerometer reading so the implied
    /// gravity matches it exactly (yaw arbitrary = 0, matching the
    /// XArbitraryZVertical reference Apple uses without a magnetometer).
    fn new(accel: (f64, f64, f64)) -> MotionFilter {
        let g = attitude_normalize_vec(accel);
        MotionFilter {
            q: quat_shortest_arc(g, (0.0, 0.0, -1.0)),
            last: Instant::now(),
            smoothed_accel: accel,
            gyro_bias: (0.0, 0.0, 0.0),
        }
    }

    /// One filter step; `now` is the current instant, `allow_gyro` disables
    /// integration for the TOUCHHLE_NO_MOTION_GYRO diagnostic mode.
    /// Returns (gravity estimate, user acceleration), both device frame.
    fn step(
        &mut self,
        gyro: (f64, f64, f64),
        accel: (f64, f64, f64),
        now: Instant,
        allow_gyro: bool,
    ) -> ((f64, f64, f64), (f64, f64, f64)) {
        let dt = now
            .duration_since(self.last)
            .min(std::time::Duration::from_secs(1))
            .as_secs_f64();
        self.last = now;

        // 0. Low-pass the accelerometer input (limits ~[0, 5Hz] content for
        //    the gravity anchor; kills sensor wobble in a resting hand).
        let lerp_t = (1.0 - (-dt / ATTITUDE_ACCEL_LPF_TAU).exp()).clamp(0.0, 1.0);
        self.smoothed_accel = vec_lerp(self.smoothed_accel, accel, lerp_t);

        // 0b. Learn the gyroscope bias while the device is evidently
        //     stationary: raw magnitude near 1g *and* no recent change
        //     between the raw sample and its own low-pass. Learning is
        //     deliberately one-sided (only from accel evidence), so even a
        //     huge constant gyro offset eventually converges instead of
        //     spinning the estimate forever.
        let raw_len = vec_len(accel);
        let recent_change = vec_len(vec_sub(accel, self.smoothed_accel));
        let gyro_is_bias_evidence = (raw_len - 1.0).abs() < 0.05
            && recent_change < 0.01
            && vec_len(gyro) <= ATTITUDE_BIAS_MAX_RATE;
        if gyro_is_bias_evidence && dt > 0.0 {
            let bias_t = (dt / ATTITUDE_BIAS_TAU).clamp(0.0, 1.0);
            self.gyro_bias = vec_lerp(self.gyro_bias, gyro, bias_t);
        }
        let gyro_clean = vec_sub(gyro, self.gyro_bias);

        // 1. Integrate the (debiased) gyroscope: body-frame rate => right
        //    multiply. This is the smooth, low-latency part of the motion.
        if allow_gyro && dt > 0.0 && dt <= ATTITUDE_MAX_GYRO_DT {
            let angular_speed = vec_len(gyro_clean);
            if angular_speed > ATTITUDE_EPSILON {
                let half_angle = angular_speed * dt * 0.5;
                let vector_scale = half_angle.sin() / angular_speed;
                let dq = (
                    gyro_clean.0 * vector_scale,
                    gyro_clean.1 * vector_scale,
                    gyro_clean.2 * vector_scale,
                    half_angle.cos(),
                );
                self.q = quat_normalized(quat_mul(self.q, dq));
            }
        }

        // 2. Gravity correction, from the *smoothed* samples; trust is
        //    decided on the *raw* magnitude so shaking disables it.
        let sm_len = vec_len(self.smoothed_accel);
        let trust_weight = if raw_len > 1.0e-3 {
            (1.0 - (raw_len - 1.0).abs() / ATTITUDE_ACCEL_TRUST_BAND).clamp(0.0, 1.0)
        } else {
            0.0
        };
        if sm_len > 1.0e-3 && trust_weight > 0.0 {
            let measured_g = (
                self.smoothed_accel.0 / sm_len,
                self.smoothed_accel.1 / sm_len,
                self.smoothed_accel.2 / sm_len,
            );
            let predicted_g = quat_world_to_device(self.q, (0.0, 0.0, -1.0));
            // NOTE the arc direction: the implied gravity is
            // quat_world_to_device(q, ¦-z¦) = R(q)^-1(-z), and extending
            // q <- q*r rotates the implied vector by R(r)^-1. To move the
            // predicted vector towards the measured one the correction arc
            // must map *measured -> predicted*; its inverse then maps
            // predicted -> measured.
            let correction = quat_shortest_arc(measured_g, predicted_g);
            let gain = (dt * ATTITUDE_CORRECTION_PER_SEC * trust_weight).clamp(0.0, 1.0);
            let correction = quat_scale_angle(correction, gain);
            self.q = quat_normalized(quat_mul(self.q, correction));
        }

        // 3. Derived outputs.
        let gravity = quat_world_to_device(self.q, (0.0, 0.0, -1.0));
        let user = vec_sub(accel, gravity);
        (gravity, user)
    }
}

/// Rotate world-frame vector `v` into the device frame expressed by
/// attitude quaternion `q` (q maps device orientation -> world; applying the
/// conjugate gives world->device).
fn quat_world_to_device(q: (f64, f64, f64, f64), v: (f64, f64, f64)) -> (f64, f64, f64) {
    let (qx, qy, qz, qw) = q;
    // v' = q^-1 * v * q, expanded without building intermediate quaternions.
    let (vx, vy, vz) = v;
    // t = 2 * q_vec x v
    let tx = 2.0 * (qy * vz - qz * vy);
    let ty = 2.0 * (qz * vx - qx * vz);
    let tz = 2.0 * (qx * vy - qy * vx);
    // v' = v - qw * t + q_vec x t ... (conjugate form of q v q*)
    (
        vx - qw * tx + (qy * tz - qz * ty),
        vy - qw * ty + (qz * tx - qx * tz),
        vz - qw * tz + (qx * ty - qy * tx),
    )
}

/// Compute the shortest-arc quaternion rotating vector `from` onto `to`
/// (both need not be normalised). Used for gravity-vector corrections.
fn quat_shortest_arc(from: (f64, f64, f64), to: (f64, f64, f64)) -> (f64, f64, f64, f64) {
    let (fx, fy, fz) = from;
    let (tx, ty, tz) = to;
    let cross = (fy * tz - fz * ty, fz * tx - fx * tz, fx * ty - fy * tx);
    let dot = fx * tx + fy * ty + fz * tz;
    let w = ((fx * fx + fy * fy + fz * fz) * (tx * tx + ty * ty + tz * tz)).sqrt() + dot;
    let mut q = (cross.0, cross.1, cross.2, w);
    let norm = (q.0 * q.0 + q.1 * q.1 + q.2 * q.2 + q.3 * q.3).sqrt();
    if norm < ATTITUDE_EPSILON {
        // Vectors are opposite; pick any perpendicular axis.
        return (1.0, 0.0, 0.0, 0.0);
    }
    q.0 /= norm;
    q.1 /= norm;
    q.2 /= norm;
    q.3 /= norm;
    q
}

/// Slerp-style attenuation of a corrective quaternion: scale its rotation
/// angle by `gain` in [0, 1].
fn quat_scale_angle(q: (f64, f64, f64, f64), gain: f64) -> (f64, f64, f64, f64) {
    let (qx, qy, qz, qw) = q;
    let half_angle = qw.clamp(-1.0, 1.0).acos();
    let scaled = half_angle * gain;
    let sin_scaled = scaled.sin();
    let sin_half = half_angle.sin();
    if sin_half.abs() < ATTITUDE_EPSILON {
        return (0.0, 0.0, 0.0, 1.0);
    }
    let factor = sin_scaled / sin_half;
    (
        qx * factor,
        qy * factor,
        qz * factor,
        scaled.cos(),
    )
}

fn quat_mul(a: (f64, f64, f64, f64), b: (f64, f64, f64, f64)) -> (f64, f64, f64, f64) {
    let (ax, ay, az, aw) = a;
    let (bx, by, bz, bw) = b;
    (
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz,
    )
}

fn quat_normalized(q: (f64, f64, f64, f64)) -> (f64, f64, f64, f64) {
    let norm = (q.0 * q.0 + q.1 * q.1 + q.2 * q.2 + q.3 * q.3).sqrt();
    if norm < ATTITUDE_EPSILON {
        (0.0, 0.0, 0.0, 1.0)
    } else {
        (q.0 / norm, q.1 / norm, q.2 / norm, q.3 / norm)
    }
}

/// Normalise a 3-vector, returning the unit vector (or (0, 0, -1) for
/// degenerate input).
fn attitude_normalize_vec(v: (f64, f64, f64)) -> (f64, f64, f64) {
    let len = (v.0 * v.0 + v.1 * v.1 + v.2 * v.2).sqrt();
    if len < ATTITUDE_EPSILON {
        (0.0, 0.0, -1.0)
    } else {
        (v.0 / len, v.1 / len, v.2 / len)
    }
}

#[cfg(test)]
mod motion_filter_tests {
    use super::MotionFilter;
    use std::time::Duration;

    #[test]
    fn slow_turn_is_not_learned_as_gyro_bias() {
        let mut filter = MotionFilter::new((0.0, 0.0, -1.0));
        let start = filter.last;
        for i in 1..=200 {
            filter.step(
                (0.03, 0.0, 0.0),
                (0.0, 0.0, -1.0),
                start + Duration::from_millis(i * 10),
                true,
            );
        }
        assert_eq!(filter.gyro_bias.0, 0.0);
    }

    #[test]
    fn stationary_small_gyro_bias_is_still_learned() {
        let mut filter = MotionFilter::new((0.0, 0.0, -1.0));
        let start = filter.last;
        for i in 1..=200 {
            filter.step(
                (0.01, 0.0, 0.0),
                (0.0, 0.0, -1.0),
                start + Duration::from_millis(i * 10),
                true,
            );
        }
        assert!(filter.gyro_bias.0 > 0.006);
    }

    #[test]
    fn gyro_integrates_a_200ms_poll_interval() {
        let mut filter = MotionFilter::new((0.0, 0.0, -2.0));
        let next = filter.last + Duration::from_millis(200);
        filter.step((1.0, 0.0, 0.0), (0.0, 0.0, -2.0), next, true);
        assert!((filter.q.0 - 0.1f64.sin()).abs() < 1.0e-9);
        assert!((filter.q.3 - 0.1f64.cos()).abs() < 1.0e-9);
    }

    #[test]
    fn accelerometer_filter_responds_faster_without_disabling_smoothing() {
        let mut filter = MotionFilter::new((0.0, 0.0, -1.0));
        let next = filter.last + Duration::from_millis(100);
        filter.step((0.0, 0.0, 0.0), (0.2, 0.0, -1.0), next, true);
        assert!(filter.smoothed_accel.0 > 0.09);
        assert!(filter.smoothed_accel.0 < 0.11);
    }
}

const CLASSES: ClassExports = objc_classes! {

(env, this, _cmd);

// =============================================================================
// CMAccelerometerData
// Per Apple: Encapsulates a single accelerometer sample.
// =============================================================================

@implementation CMAccelerometerData: NSObject

+ (id)allocWithZone:(NSZonePtr)_zone {
    let host_object = Box::new(CMAccelerometerDataHostObject {
        acceleration: CMAcceleration { x: 0.0, y: 0.0, z: -1.0 },
        timestamp: 0.0,
    });
    env.objc.alloc_object(this, host_object, &mut env.mem)
}

- (CMAcceleration)acceleration {
    env.objc.borrow::<CMAccelerometerDataHostObject>(this).acceleration
}

- (f64)timestamp {
    env.objc.borrow::<CMAccelerometerDataHostObject>(this).timestamp
}

- (f64)_accelerationX {
    env.objc.borrow::<CMAccelerometerDataHostObject>(this).acceleration.x
}
- (f64)_accelerationY {
    env.objc.borrow::<CMAccelerometerDataHostObject>(this).acceleration.y
}
- (f64)_accelerationZ {
    env.objc.borrow::<CMAccelerometerDataHostObject>(this).acceleration.z
}

- (id)description {
    let host = env.objc.borrow::<CMAccelerometerDataHostObject>(this);
    let acceleration = host.acceleration;
    let (x, y, z) = (acceleration.x, acceleration.y, acceleration.z);
    let s = format!(
        "<CMAccelerometerData: timestamp={:.4} x={:.4} y={:.4} z={:.4}>",
        host.timestamp, x, y, z
    );
    let cstr = env.mem.alloc_and_write_cstr(s.as_bytes());
    msg_class![env; NSString stringWithUTF8String:cstr]
}

@end

// =============================================================================
// CMGyroData
// =============================================================================

@implementation CMGyroData: NSObject

+ (id)allocWithZone:(NSZonePtr)_zone {
    let host_object = Box::new(CMGyroDataHostObject {
        rotation_rate: CMRotationRate { x: 0.0, y: 0.0, z: 0.0 },
        timestamp: 0.0,
    });
    env.objc.alloc_object(this, host_object, &mut env.mem)
}

- (CMRotationRate)rotationRate {
    env.objc.borrow::<CMGyroDataHostObject>(this).rotation_rate
}

- (f64)timestamp {
    env.objc.borrow::<CMGyroDataHostObject>(this).timestamp
}

- (f64)_rotationRateX {
    env.objc.borrow::<CMGyroDataHostObject>(this).rotation_rate.x
}
- (f64)_rotationRateY {
    env.objc.borrow::<CMGyroDataHostObject>(this).rotation_rate.y
}
- (f64)_rotationRateZ {
    env.objc.borrow::<CMGyroDataHostObject>(this).rotation_rate.z
}

@end

// =============================================================================
// CMAttitude
// Per Apple: describes the orientation of the device as roll/pitch/yaw
// (radians), plus a rotation matrix and quaternion. With no real host gyro
// desktop/Android hosts, we derive roll/pitch from the gravity vector and
// leave yaw at zero. This is enough for games that only read the property to
// avoid the generic "does not respond to selector" path (which floods the log
// and slows the whole emulator down).
// =============================================================================

@implementation CMAttitude: NSObject

+ (id)allocWithZone:(NSZonePtr)_zone {
    let host_object = Box::new(CMAttitudeHostObject::default());
    env.objc.alloc_object(this, host_object, &mut env.mem)
}

- (f64)roll {
    env.objc.borrow::<CMAttitudeHostObject>(this).attitude.roll
}

- (f64)pitch {
    env.objc.borrow::<CMAttitudeHostObject>(this).attitude.pitch
}

- (f64)yaw {
    env.objc.borrow::<CMAttitudeHostObject>(this).attitude.yaw
}

- (CMQuaternion)quaternion {
    env.objc.borrow::<CMAttitudeHostObject>(this).quaternion
}

- (CMRotationMatrix)rotationMatrix {
    let q = env.objc.borrow::<CMAttitudeHostObject>(this).quaternion;
    quat_to_rotation_matrix((q.x, q.y, q.z, q.w))
}

// Per Apple docs, this is how apps turn the absolute world-frame attitude
// into one relative to a stored reference attitude (i.e. "calibrate" the
// neutral pose when a camera mode starts). Games' 3D tilt cameras rely on
// this — without it they fall back to the absolute attitude, which in the
// upright gaming hold sits near its extremes and makes a tiny tilt swing
// the camera wildly. In-place per Apple's signature.
- (())multiplyByInverseOfAttitude:(id)other {
    let q_ref = {
        let CMQuaternion { x, y, z, w } =
            env.objc.borrow::<CMAttitudeHostObject>(other).quaternion;
        (x, y, z, w)
    };
    let q_self = {
        let CMQuaternion { x, y, z, w } =
            env.objc.borrow::<CMAttitudeHostObject>(this).quaternion;
        (x, y, z, w)
    };
    // q_out = q_self * inverse(q_ref), and the inverse of a unit quaternion
    // is its conjugate.
    let q_ref_inv = (-q_ref.0, -q_ref.1, -q_ref.2, q_ref.3);
    let q_out = quat_normalized(quat_mul(q_self, q_ref_inv));
    let (pitch, roll, yaw) = quat_to_apple_angles(q_out);
    let host = env.objc.borrow_mut::<CMAttitudeHostObject>(this);
    host.quaternion = CMQuaternion {
        x: q_out.0,
        y: q_out.1,
        z: q_out.2,
        w: q_out.3,
    };
    host.attitude = CMAttitude { roll, pitch, yaw };
}

@end

// =============================================================================
// CMDeviceMotion
// =============================================================================

@implementation CMDeviceMotion: NSObject

+ (id)allocWithZone:(NSZonePtr)_zone {
    let host_object = Box::new(CMDeviceMotionHostObject {
        gravity: CMAcceleration { x: 0.0, y: 0.0, z: -1.0 },
        user_acceleration: CMAcceleration { x: 0.0, y: 0.0, z: 0.0 },
        rotation_rate: CMRotationRate { x: 0.0, y: 0.0, z: 0.0 },
        timestamp: 0.0,
        attitude: CMAttitude::default(),
        quaternion: CMQuaternion { x: 0.0, y: 0.0, z: 0.0, w: 1.0 },
    });
    env.objc.alloc_object(this, host_object, &mut env.mem)
}

- (id)attitude {
    let (attitude_angles, quaternion) = {
        let host = env.objc.borrow::<CMDeviceMotionHostObject>(this);
        (host.attitude, host.quaternion)
    };
    let attitude: id = msg_class![env; CMAttitude new];
    {
        let attitude_host = env.objc.borrow_mut::<CMAttitudeHostObject>(attitude);
        attitude_host.attitude = attitude_angles;
        attitude_host.quaternion = quaternion;
    }
    autorelease(env, attitude)
}

- (CMAcceleration)gravity {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).gravity
}

- (CMAcceleration)userAcceleration {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).user_acceleration
}

- (CMRotationRate)rotationRate {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).rotation_rate
}

- (f64)timestamp {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).timestamp
}

- (f64)_gravityX {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).gravity.x
}
- (f64)_gravityY {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).gravity.y
}
- (f64)_gravityZ {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).gravity.z
}

- (f64)_userAccelerationX {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).user_acceleration.x
}
- (f64)_userAccelerationY {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).user_acceleration.y
}
- (f64)_userAccelerationZ {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).user_acceleration.z
}

- (f64)_rotationRateX {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).rotation_rate.x
}
- (f64)_rotationRateY {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).rotation_rate.y
}
- (f64)_rotationRateZ {
    env.objc.borrow::<CMDeviceMotionHostObject>(this).rotation_rate.z
}

@end

// =============================================================================
// CMMotionManager
// Per Apple: The gateway object for the device's accelerometer, gyroscope,
// and device-motion services. Your app creates an instance of this class and
// uses its properties and methods to:
//   - Determine which sensors are available (isAccelerometerAvailable, etc.)
//   - Set the update interval
//   - Start/stop updates
//   - Retrieve the most recent data (accelerometerData, gyroData, deviceMotion)
// =============================================================================

@implementation CMMotionManager: NSObject

+ (id)allocWithZone:(NSZonePtr)_zone {
    let host_object = Box::new(CMMotionManagerHostObject {
        accelerometer_update_interval: 1.0 / 60.0, // 60Hz default per Apple docs
        gyro_update_interval: 1.0 / 60.0,
        device_motion_update_interval: 1.0 / 60.0,
        accelerometer_active: false,
        gyro_active: false,
        device_motion_active: false,
        last_acceleration: CMAcceleration { x: 0.0, y: 0.0, z: -1.0 },
        last_accel_timestamp: 0.0,
        start_time: Some(Instant::now()),
        attitude_state: None,
    });
    env.objc.alloc_object(this, host_object, &mut env.mem)
}

// =========================================================================
// Availability checks
// Per Apple: These indicate whether the hardware sensor is available.
// On the emulator: accelerometer and gyroscope come from SDL sensors (with a
// stationary-device stub fallback); magnetometer is not emulated.
// =========================================================================

- (bool)isAccelerometerAvailable {
    // Accelerometer is available if we have an SDL sensor or if user has a
    // mouse (virtual accelerometer via right-click).
    true
}

- (bool)isGyroAvailable {
    // The gyroscope is always reported as available. If the host exposes a
    // real gyro sensor via SDL its readings are used; otherwise readings fall
    // back to a "stationary device" stub (zero rotation rate). Apps commonly
    // gate their motion features on this flag, so a stubbed-but-available
    // gyro is preferable to reporting the hardware as absent.
    true
}

- (bool)isDeviceMotionAvailable {
    // Device motion requires both accelerometer + gyro for full fusion.
    // We can provide gravity-only device motion from accelerometer alone.
    true
}

- (bool)isMagnetometerAvailable {
    false
}

// =========================================================================
// Update intervals
// Per Apple: The interval, in seconds, for providing accelerometer updates.
// A value of 0 means updates come as fast as possible.
// =========================================================================

- (())setAccelerometerUpdateInterval:(f64)interval {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).accelerometer_update_interval =
        if interval <= 0.0 { 1.0 / 100.0 } else { interval };
}

- (f64)accelerometerUpdateInterval {
    env.objc.borrow::<CMMotionManagerHostObject>(this).accelerometer_update_interval
}

- (())setGyroUpdateInterval:(f64)interval {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).gyro_update_interval =
        if interval <= 0.0 { 1.0 / 100.0 } else { interval };
}

- (f64)gyroUpdateInterval {
    env.objc.borrow::<CMMotionManagerHostObject>(this).gyro_update_interval
}

- (())setDeviceMotionUpdateInterval:(f64)interval {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).device_motion_update_interval =
        if interval <= 0.0 { 1.0 / 100.0 } else { interval };
}

- (f64)deviceMotionUpdateInterval {
    env.objc.borrow::<CMMotionManagerHostObject>(this).device_motion_update_interval
}

// =========================================================================
// Start/Stop updates (pull mode — app reads accelerometerData on demand)
// =========================================================================

- (())startAccelerometerUpdates {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).accelerometer_active = true;
}

- (())stopAccelerometerUpdates {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).accelerometer_active = false;
}

- (())startGyroUpdates {
    if env.window.as_ref().is_none_or(|w| !w.has_gyroscope()) {
        log!("No host gyroscope sensor; reporting a stationary device (zero rotation rate).");
    }
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).gyro_active = true;
}

- (())stopGyroUpdates {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).gyro_active = false;
}

- (())startDeviceMotionUpdates {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).device_motion_active = true;
}

- (())stopDeviceMotionUpdates {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).device_motion_active = false;
}

// Push mode (handler-based) — we activate the sensor but do NOT call
// handlers since that would require implementing NSOperationQueue dispatch.
// Games that use pull-mode (polling accelerometerData) still work perfectly.
- (())startAccelerometerUpdatesToQueue:(id)_queue withHandler:(id)_handler {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).accelerometer_active = true;
}

- (())startGyroUpdatesToQueue:(id)_queue withHandler:(id)_handler {
    if env.window.as_ref().is_none_or(|w| !w.has_gyroscope()) {
        log!("No host gyroscope sensor; reporting a stationary device (zero rotation rate).");
    }
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).gyro_active = true;
}

- (())startDeviceMotionUpdatesToQueue:(id)_queue withHandler:(id)_handler {
    env.objc.borrow_mut::<CMMotionManagerHostObject>(this).device_motion_active = true;
}

// =========================================================================
// Active state queries
// =========================================================================

- (bool)isAccelerometerActive {
    env.objc.borrow::<CMMotionManagerHostObject>(this).accelerometer_active
}

- (bool)isGyroActive {
    env.objc.borrow::<CMMotionManagerHostObject>(this).gyro_active
}

- (bool)isDeviceMotionActive {
    env.objc.borrow::<CMMotionManagerHostObject>(this).device_motion_active
}

// `-[CMMotionManager isMagnetometerActive]` — per
// <https://developer.apple.com/documentation/coremotion/cmmotionmanager/1616080-magnetometeractive>.
// touchHLE never enables the magnetometer (we report `isMagnetometerAvailable`
// as `NO`), so this always returns `NO`. Apple's documentation requires
// the property be queryable even when the hardware is absent.
- (bool)isMagnetometerActive {
    false
}

// Companion symmetric APIs for the magnetometer-pull-mode API. Apple
// documents `startMagnetometerUpdates` / `stopMagnetometerUpdates` and
// the `magnetometerData` accessor in
// <https://developer.apple.com/documentation/coremotion/cmmotionmanager>.
// With no hardware backing we still acknowledge the calls so that apps
// guarding magnetometer use behind `isMagnetometerAvailable` continue to
// run without crashing if they call these unconditionally.
- (())startMagnetometerUpdates {
}
- (())stopMagnetometerUpdates {
}
- (())startMagnetometerUpdatesToQueue:(id)_queue withHandler:(id)_handler {
}
- (id)magnetometerData {
    nil
}
- (())setMagnetometerUpdateInterval:(f64)_interval {
}
- (f64)magnetometerUpdateInterval {
    0.0
}

// =========================================================================
// Data accessors (pull mode)
// Per Apple: Returns the latest sample of accelerometer/gyro/motion data,
// or nil if updates have not been started.
// =========================================================================

- (id)accelerometerData {
    let active = env.objc.borrow::<CMMotionManagerHostObject>(this).accelerometer_active;
    if !active {
        return nil;
    }

    // Read real accelerometer data from SDL sensor, or fall back to simulated
    let accel = read_sdl_accelerometer(env)
        .unwrap_or(CMAcceleration { x: 0.0, y: 0.0, z: -1.0 });

    let timestamp = env.objc.borrow::<CMMotionManagerHostObject>(this)
        .start_time.unwrap_or_else(std::time::Instant::now).elapsed().as_secs_f64();

    // Update cached value
    {
        let host = env.objc.borrow_mut::<CMMotionManagerHostObject>(this);
        host.last_acceleration = accel;
        host.last_accel_timestamp = timestamp;
    }

    // Create and return a fresh CMAccelerometerData object
    let data: id = msg_class![env; CMAccelerometerData new];
    {
        let data_host = env.objc.borrow_mut::<CMAccelerometerDataHostObject>(data);
        data_host.acceleration = accel;
        data_host.timestamp = timestamp;
    }
    autorelease(env, data)
}

- (id)gyroData {
    let active = env.objc.borrow::<CMMotionManagerHostObject>(this).gyro_active;
    if !active {
        return nil;
    }

    // Read the host gyroscope via SDL when available; otherwise fall back to
    // a "stationary device" stub (zero rotation rate) while still reporting
    // the gyroscope as available.
    let rotation_rate = read_sdl_gyroscope(env)
        .unwrap_or(CMRotationRate { x: 0.0, y: 0.0, z: 0.0 });
    let timestamp = env.objc.borrow::<CMMotionManagerHostObject>(this)
        .start_time.unwrap_or_else(std::time::Instant::now).elapsed().as_secs_f64();

    let data: id = msg_class![env; CMGyroData new];
    {
        let data_host = env.objc.borrow_mut::<CMGyroDataHostObject>(data);
        data_host.rotation_rate = rotation_rate;
        data_host.timestamp = timestamp;
    }
    autorelease(env, data)
}

- (id)deviceMotion {
    let active = env.objc.borrow::<CMMotionManagerHostObject>(this).device_motion_active;
    if !active {
        return nil;
    }

    let accel = read_sdl_accelerometer(env)
        .unwrap_or(CMAcceleration { x: 0.0, y: 0.0, z: -1.0 });
    let rotation_rate = read_sdl_gyroscope(env)
        .unwrap_or(CMRotationRate { x: 0.0, y: 0.0, z: 0.0 });
    let timestamp = env.objc.borrow::<CMMotionManagerHostObject>(this)
        .start_time.unwrap_or_else(std::time::Instant::now).elapsed().as_secs_f64();

    // Sensor fusion: gyro-integrated attitude corrected towards gravity.
    // Without the fusion the gravity-only roll/pitch are ill-conditioned in
    // upright (gaming) holds — tiny tilts then snap the camera to full
    // deflection.
    let now = Instant::now();
    let (attitude_q, gravity_g, user_g) = {
        let accel_t = (accel.x, accel.y, accel.z);
        let gyro_t = (rotation_rate.x, rotation_rate.y, rotation_rate.z);
        // Diagnostic escape hatch: with TOUCHHLE_NO_MOTION_GYRO set, gyro
        // integration is disabled (useful on hosts whose gyro signal is
        // unusable; gravity-only operation then applies).
        let allow_gyro = !crate::env_flag_cached!("TOUCHHLE_NO_MOTION_GYRO");
        let host = env.objc.borrow_mut::<CMMotionManagerHostObject>(this);
        let filter = host
            .attitude_state
            .get_or_insert_with(|| MotionFilter::new(accel_t));
        let (gravity_g, user_g) = filter.step(gyro_t, accel_t, now, allow_gyro);
        (filter.q, gravity_g, user_g)
    };

    // Deliver the *filter's* continuous attitude quaternion and the angles
    // decomposed from it. Previously the quaternion was rebuilt from the two
    // atan2() gravity angles (yaw forced to 0): that object has seams in
    // exactly the poses people game in, and near a seam a tiny physical
    // twist produced a huge frame-to-frame quaternion delta — camera code
    // consuming the attitude/quaternion then spun the view to maximum.
    let (pitch, roll, yaw) = quat_to_apple_angles(attitude_q);
    let quaternion = CMQuaternion {
        x: attitude_q.0,
        y: attitude_q.1,
        z: attitude_q.2,
        w: attitude_q.3,
    };

    let data: id = msg_class![env; CMDeviceMotion new];
    {
        let data_host = env.objc.borrow_mut::<CMDeviceMotionHostObject>(data);
        data_host.gravity = CMAcceleration {
            x: gravity_g.0,
            y: gravity_g.1,
            z: gravity_g.2,
        };
        data_host.user_acceleration = CMAcceleration {
            x: user_g.0,
            y: user_g.1,
            z: user_g.2,
        };
        data_host.rotation_rate = rotation_rate;
        data_host.timestamp = timestamp;
        data_host.attitude = CMAttitude { roll, pitch, yaw };
        data_host.quaternion = quaternion;
    }
    autorelease(env, data)
}

@end

};
