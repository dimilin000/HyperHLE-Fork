/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
//! Minimal Metal.framework compatibility layer.
//!
//! Metal is a native Apple GPU API, while HyperHLE renders through its
//! portable GLES presentation path. This layer intentionally provides the
//! object and descriptor contract used during app startup and resource setup;
//! it does not pretend to execute Metal command streams on non-Apple hosts.

use crate::dyld::{ConstantExports, HostDylib};
use crate::frameworks::core_graphics::cg_geometry::CGRect;
use crate::frameworks::foundation::{ns_string, NSUInteger};
use crate::mem::{ConstPtr, ConstVoidPtr, GuestUSize, MutPtr, MutVoidPtr};
use crate::objc::{id, msg, msg_class, nil, objc_classes, ClassExports, HostObject, NSZonePtr};
use crate::Environment;

pub const DYLIB: HostDylib = HostDylib {
    path: "/System/Library/Frameworks/Metal.framework/Metal",
    aliases: &[],
    class_exports: &[CLASSES],
    constant_exports: &[CONSTANTS],
    function_exports: &[FUNCTIONS],
};

const MTL_RESOURCE_STORAGE_MODE_SHARED: NSUInteger = 0;
const MTL_RESOURCE_STORAGE_MODE_MANAGED: NSUInteger = 1;
const MTL_RESOURCE_STORAGE_MODE_PRIVATE: NSUInteger = 2;
const MTL_RESOURCE_STORAGE_MODE_MEMORYLESS: NSUInteger = 3;
const MTL_LOAD_ACTION_DONT_CARE: NSUInteger = 0;
const MTL_LOAD_ACTION_LOAD: NSUInteger = 1;
const MTL_LOAD_ACTION_CLEAR: NSUInteger = 2;
const MTL_STORE_ACTION_DONT_CARE: NSUInteger = 0;
const MTL_STORE_ACTION_STORE: NSUInteger = 1;
const MAX_COLOR_ATTACHMENTS: usize = 8;

#[derive(Default)]
struct MetalObjectHostObject {
    label: id,
    device: id,
    length: NSUInteger,
    contents: MutVoidPtr,
    usage: NSUInteger,
    storage_mode: NSUInteger,
    pixel_format: NSUInteger,
    width: NSUInteger,
    height: NSUInteger,
    depth: NSUInteger,
    mipmap_level_count: NSUInteger,
    sample_count: NSUInteger,
    load_action: NSUInteger,
    store_action: NSUInteger,
    clear_color: [f64; 4],
    command_buffer: id,
    layouts: id,
    attributes: id,
    stride: NSUInteger,
    front_stencil: id,
    back_stencil: id,
    step_function: NSUInteger,
    step_rate: NSUInteger,
    stencil_compare_function: NSUInteger,
    stencil_failure_operation: NSUInteger,
    depth_failure_operation: NSUInteger,
    depth_stencil_pass_operation: NSUInteger,
    write_mask: NSUInteger,
    read_mask: NSUInteger,
    frame: CGRect,
    bounds: CGRect,
    vertex_function: id,
    fragment_function: id,
    depth_pixel_format: NSUInteger,
    stencil_pixel_format: NSUInteger,
    blending_enabled: bool,
    source_rgb_blend_factor: NSUInteger,
    destination_rgb_blend_factor: NSUInteger,
    source_alpha_blend_factor: NSUInteger,
    destination_alpha_blend_factor: NSUInteger,
    rgb_blend_operation: NSUInteger,
    alpha_blend_operation: NSUInteger,
    color_attachments: [id; MAX_COLOR_ATTACHMENTS],
}
impl HostObject for MetalObjectHostObject {}

#[derive(Clone, Copy)]
struct SamplerDescriptorSettings {
    label: id,
    min_filter: NSUInteger,
    mag_filter: NSUInteger,
    mip_filter: NSUInteger,
    max_anisotropy: NSUInteger,
    s_address_mode: NSUInteger,
    t_address_mode: NSUInteger,
    r_address_mode: NSUInteger,
    border_color: NSUInteger,
    normalized_coordinates: bool,
    lod_min_clamp: f32,
    lod_max_clamp: f32,
    lod_bias: f32,
    lod_average: bool,
    compare_function: NSUInteger,
    support_argument_buffers: bool,
    reduction_mode: NSUInteger,
}

impl Default for SamplerDescriptorSettings {
    fn default() -> Self {
        Self {
            label: nil,
            min_filter: 0,
            mag_filter: 0,
            mip_filter: 0,
            max_anisotropy: 1,
            s_address_mode: 0,
            t_address_mode: 0,
            r_address_mode: 0,
            border_color: 0,
            normalized_coordinates: true,
            lod_min_clamp: 0.0,
            lod_max_clamp: f32::MAX,
            lod_bias: 0.0,
            lod_average: false,
            compare_function: 0,
            support_argument_buffers: false,
            reduction_mode: 0,
        }
    }
}

struct SamplerDescriptorHostObject {
    settings: SamplerDescriptorSettings,
}

impl Default for SamplerDescriptorHostObject {
    fn default() -> Self {
        Self {
            settings: SamplerDescriptorSettings::default(),
        }
    }
}

impl HostObject for SamplerDescriptorHostObject {}

struct SamplerStateHostObject {
    device: id,
    settings: SamplerDescriptorSettings,
    gpu_resource_id: u64,
}

impl Default for SamplerStateHostObject {
    fn default() -> Self {
        Self {
            device: nil,
            settings: SamplerDescriptorSettings::default(),
            gpu_resource_id: 0,
        }
    }
}

impl HostObject for SamplerStateHostObject {}

#[cfg(test)]
mod sampler_tests {
    use super::{SamplerDescriptorSettings, SamplerStateHostObject};
    use crate::objc::nil;

    #[test]
    fn descriptor_defaults_match_metal() {
        let settings = SamplerDescriptorSettings::default();
        assert_eq!(settings.min_filter, 0);
        assert_eq!(settings.mag_filter, 0);
        assert_eq!(settings.mip_filter, 0);
        assert_eq!(settings.max_anisotropy, 1);
        assert_eq!(settings.s_address_mode, 0);
        assert_eq!(settings.t_address_mode, 0);
        assert_eq!(settings.r_address_mode, 0);
        assert_eq!(settings.border_color, 0);
        assert!(settings.normalized_coordinates);
        assert_eq!(settings.lod_min_clamp, 0.0);
        assert_eq!(settings.lod_max_clamp, f32::MAX);
        assert_eq!(settings.lod_bias, 0.0);
        assert!(!settings.lod_average);
        assert_eq!(settings.compare_function, 0);
        assert!(!settings.support_argument_buffers);
        assert_eq!(settings.reduction_mode, 0);
    }

    #[test]
    fn sampler_state_keeps_descriptor_snapshot_and_device() {
        let mut settings = SamplerDescriptorSettings::default();
        settings.min_filter = 1;
        settings.label = nil;
        let state = SamplerStateHostObject {
            device: nil,
            settings,
            gpu_resource_id: 42,
        };
        settings.min_filter = 0;
        assert_eq!(state.settings.min_filter, 1);
        assert_eq!(state.gpu_resource_id, 42);
    }
}

fn metal_string(env: &mut Environment, value: &'static str) -> id {
    ns_string::get_static_str(env, value)
}

fn allocation_size(length: NSUInteger) -> GuestUSize {
    length.max(1)
}

fn constant_uinteger(env: &mut Environment, value: NSUInteger) -> ConstVoidPtr {
    ConstVoidPtr::from_bits(env.mem.alloc_and_write(value).to_bits())
}

const CLASSES: ClassExports = objc_classes! {
(env, this, _cmd);

@implementation MTLDevice: NSObject

+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
// Some apps treat the MTLDevice *class* itself as the device (e.g. calling
// [MTLDevice newBufferWithLength:options:] after getting a class object from
// a failed/nil device lookup). Real iOS answers these on the metaclass only
// for the handful of +class helpers, but being permissive here is free:
// forward every creation/probe selector to a fresh instance.
+ (id)name { metal_string(env, "HyperHLE Metal compatibility device") }
+ (bool)hasUnifiedMemory { true }
+ (bool)supportsFamily:(NSUInteger)family {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device supportsFamily:family]
}
+ (bool)supportsFeatureSet:(NSUInteger)feature_set {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device supportsFeatureSet:feature_set]
}
+ (bool)supportsTextureSampleCount:(NSUInteger)count {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device supportsTextureSampleCount:count]
}
+ (id)newCommandQueue {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newCommandQueue]
}
+ (id)newCommandQueueWithMaxCommandBufferCount:(NSUInteger)count {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newCommandQueueWithMaxCommandBufferCount:count]
}
+ (id)newBufferWithLength:(NSUInteger)length options:(NSUInteger)options {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newBufferWithLength:length options:options]
}
+ (id)newBufferWithBytes:(ConstVoidPtr)bytes length:(NSUInteger)length options:(NSUInteger)options {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newBufferWithBytes:bytes length:length options:options]
}
+ (id)newTextureWithDescriptor:(id)descriptor {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newTextureWithDescriptor:descriptor]
}
+ (id)newLibraryWithSource:(id)source options:(id)options error:(MutPtr<id>)error {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newLibraryWithSource:source options:options error:error]
}
+ (id)newLibraryWithData:(ConstVoidPtr)data error:(MutPtr<id>)error {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newLibraryWithData:data error:error]
}
+ (id)newLibraryWithFile:(ConstPtr<u8>)path error:(MutPtr<id>)error {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newLibraryWithFile:path error:error]
}
+ (id)newSamplerStateWithDescriptor:(id)descriptor {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newSamplerStateWithDescriptor:descriptor]
}
+ (id)newRenderPipelineStateWithDescriptor:(id)descriptor error:(MutPtr<id>)error {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newRenderPipelineStateWithDescriptor:descriptor error:error]
}
+ (id)newDepthStencilStateWithDescriptor:(id)descriptor {
    let device: id = msg_class![env; MTLDevice new];
    msg![env; device newDepthStencilStateWithDescriptor:descriptor]
}

- (id)init { this }
- (id)name { metal_string(env, "HyperHLE Metal compatibility device") }
- (bool)hasUnifiedMemory { true }
- (NSUInteger)recommendedMaxWorkingSetSize { 0 }
- (bool)supportsFamily:(NSUInteger)_family { false }
- (bool)supportsTextureSampleCount:(NSUInteger)count { count == 1 }
- (id)newCommandQueue { msg_class![env; MTLCommandQueue new] }
- (id)newCommandQueueWithMaxCommandBufferCount:(NSUInteger)_count { msg_class![env; MTLCommandQueue new] }
- (id)newBufferWithLength:(NSUInteger)length options:(NSUInteger)options {
    let object = msg_class![env; MTLBuffer alloc];
    let contents = env.mem.alloc(allocation_size(length));
    let host = env.objc.borrow_mut::<MetalObjectHostObject>(object);
    host.length = length;
    host.storage_mode = options & 0xf;
    host.contents = contents;
    object
}
- (id)newBufferWithBytes:(ConstVoidPtr)bytes length:(NSUInteger)length options:(NSUInteger)options {
    let object = msg![env; this newBufferWithLength:length options:options];
    if !bytes.is_null() && length != 0 {
        let source = env.mem.bytes_at(bytes.cast(), length).to_vec();
        let destination_ptr = env.objc.borrow::<MetalObjectHostObject>(object).contents;
        env.mem.bytes_at_mut(destination_ptr.cast(), length).copy_from_slice(&source);
    }
    object
}
- (id)newTextureWithDescriptor:(id)descriptor {
    let object = msg_class![env; MTLTexture alloc];
    let source = env.objc.borrow::<MetalObjectHostObject>(descriptor);
    let device = source.device;
    let pixel_format = source.pixel_format;
    let width = source.width;
    let height = source.height;
    let depth = source.depth;
    let mipmap_level_count = source.mipmap_level_count;
    let sample_count = source.sample_count;
    let host = env.objc.borrow_mut::<MetalObjectHostObject>(object);
    host.device = if device == nil { this } else { device };
    host.pixel_format = pixel_format;
    host.width = width;
    host.height = height;
    host.depth = depth;
    host.mipmap_level_count = mipmap_level_count;
    host.sample_count = sample_count;
    object
}
- (id)newLibraryWithSource:(id)_source options:(id)_options error:(MutPtr<id>)_error {
    // Runtime shader compilation: the game compiles MSL at startup. Without a
    // host GPU to translate it to, we hand back an object that behaves like an
    // empty library — function lookups return real MTLFunction objects whose
    // handles the app can attach to pipeline descriptors.
    msg_class![env; MTLLibrary new]
}
- (id)newLibraryWithData:(ConstVoidPtr)_data error:(MutPtr<id>)_error { msg_class![env; MTLLibrary new] }
- (id)newLibraryWithFile:(ConstPtr<u8>)_path error:(MutPtr<id>)_error { msg_class![env; MTLLibrary new] }
- (id)newSamplerStateWithDescriptor:(id)descriptor {
    let settings = if descriptor == nil {
        SamplerDescriptorSettings::default()
    } else {
        env.objc
            .borrow::<SamplerDescriptorHostObject>(descriptor)
            .settings
    };
    let state = msg_class![env; TouchHLEMTLSamplerState new];
    let host = env.objc.borrow_mut::<SamplerStateHostObject>(state);
    host.device = this;
    host.settings = settings;
    host.gpu_resource_id = state.to_bits() as u64;
    state
}
- (id)newRenderPipelineStateWithDescriptor:(id)_descriptor error:(MutPtr<id>)_error { msg_class![env; MTLRenderPipelineState new] }
- (id)newDepthStencilStateWithDescriptor:(id)_descriptor { msg_class![env; MTLDepthStencilState new] }
- (bool)supportsFeatureSet:(NSUInteger)_feature_set {
    // Asphalt 9 probes feature sets before creating its Metal device.
    // The iOS 7-era feature sets (1-5) are universally supported by the
    // GLES presentation path; later A9+ feature sets are reported as
    // unsupported so apps pick their legacy pipeline.
    _feature_set <= 5
}

@end

@implementation MTLSamplerDescriptor: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(SamplerDescriptorHostObject::default()), &mut env.mem)
}
- (id)init { this }
- (id)copyWithZone:(NSZonePtr)_zone {
    let copy = msg_class![env; MTLSamplerDescriptor new];
    let settings = env.objc.borrow::<SamplerDescriptorHostObject>(this).settings;
    env.objc.borrow_mut::<SamplerDescriptorHostObject>(copy).settings = settings;
    copy
}
- (id)label { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.label }
- (())setLabel:(id)label {
    let label = if label == nil { nil } else { msg![env; label copy] };
    env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.label = label;
}
- (NSUInteger)minFilter { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.min_filter }
- (())setMinFilter:(NSUInteger)filter { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.min_filter = filter }
- (NSUInteger)magFilter { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.mag_filter }
- (())setMagFilter:(NSUInteger)filter { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.mag_filter = filter }
- (NSUInteger)mipFilter { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.mip_filter }
- (())setMipFilter:(NSUInteger)filter { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.mip_filter = filter }
- (NSUInteger)maxAnisotropy { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.max_anisotropy }
- (())setMaxAnisotropy:(NSUInteger)anisotropy { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.max_anisotropy = anisotropy }
- (NSUInteger)sAddressMode { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.s_address_mode }
- (())setSAddressMode:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.s_address_mode = mode }
- (NSUInteger)addressModeS { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.s_address_mode }
- (())setAddressModeS:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.s_address_mode = mode }
- (NSUInteger)tAddressMode { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.t_address_mode }
- (())setTAddressMode:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.t_address_mode = mode }
- (NSUInteger)addressModeT { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.t_address_mode }
- (())setAddressModeT:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.t_address_mode = mode }
- (NSUInteger)rAddressMode { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.r_address_mode }
- (())setRAddressMode:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.r_address_mode = mode }
- (NSUInteger)addressModeR { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.r_address_mode }
- (())setAddressModeR:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.r_address_mode = mode }
- (NSUInteger)borderColor { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.border_color }
- (())setBorderColor:(NSUInteger)color { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.border_color = color }
- (bool)normalizedCoordinates { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.normalized_coordinates }
- (())setNormalizedCoordinates:(bool)normalized { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.normalized_coordinates = normalized }
- (f32)lodMinClamp { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.lod_min_clamp }
- (())setLodMinClamp:(f32)clamp { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.lod_min_clamp = clamp }
- (f32)lodMaxClamp { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.lod_max_clamp }
- (())setLodMaxClamp:(f32)clamp { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.lod_max_clamp = clamp }
- (f32)lodBias { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.lod_bias }
- (())setLodBias:(f32)bias { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.lod_bias = bias }
- (bool)lodAverage { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.lod_average }
- (())setLodAverage:(bool)average { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.lod_average = average }
- (NSUInteger)compareFunction { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.compare_function }
- (())setCompareFunction:(NSUInteger)function { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.compare_function = function }
- (bool)supportArgumentBuffers { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.support_argument_buffers }
- (())setSupportArgumentBuffers:(bool)supported { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.support_argument_buffers = supported }
- (NSUInteger)reductionMode { env.objc.borrow::<SamplerDescriptorHostObject>(this).settings.reduction_mode }
- (())setReductionMode:(NSUInteger)mode { env.objc.borrow_mut::<SamplerDescriptorHostObject>(this).settings.reduction_mode = mode }
@end

@implementation TouchHLEMTLSamplerState: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(SamplerStateHostObject::default()), &mut env.mem)
}
- (id)init { this }
- (id)label { env.objc.borrow::<SamplerStateHostObject>(this).settings.label }
- (())setLabel:(id)label {
    let label = if label == nil { nil } else { msg![env; label copy] };
    env.objc.borrow_mut::<SamplerStateHostObject>(this).settings.label = label;
}
- (id)device { env.objc.borrow::<SamplerStateHostObject>(this).device }
- (u64)gpuResourceID { env.objc.borrow::<SamplerStateHostObject>(this).gpu_resource_id }
@end

@implementation MTLCommandQueue: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (id)commandBuffer { let buffer = msg_class![env; MTLCommandBuffer new]; env.objc.borrow_mut::<MetalObjectHostObject>(buffer).command_buffer = this; buffer }
- (id)commandBufferWithUnretainedReferences { msg![env; this commandBuffer] }
- (id)newBufferWithLength:(NSUInteger)length options:(NSUInteger)options {
    let device = env.objc.borrow::<MetalObjectHostObject>(this).device;
    if device != nil {
        msg![env; device newBufferWithLength:length options:options]
    } else {
        msg_class![env; MTLDevice newBufferWithLength:length options:options]
    }
}
@end

@implementation MTLCommandBuffer: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (id)renderCommandEncoderWithDescriptor:(id)_descriptor { msg_class![env; RMTLRenderCommandEncoder new] }
- (())enqueue {}
- (())commit {}
- (())waitUntilCompleted {}
- (())presentDrawable:(id)_drawable {}
- (id)device { env.objc.borrow::<MetalObjectHostObject>(this).command_buffer }
- (NSUInteger)status { 0 }
@end

@implementation MTLRenderCommandEncoder: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (())endEncoding {}
- (())setRenderPipelineState:(id)_state {}
- (())setVertexBuffer:(id)_buffer offset:(NSUInteger)_offset atIndex:(NSUInteger)_index {}
- (())setFragmentBuffer:(id)_buffer offset:(NSUInteger)_offset atIndex:(NSUInteger)_index {}
- (())setVertexTexture:(id)_texture atIndex:(NSUInteger)_index {}
- (())setFragmentTexture:(id)_texture atIndex:(NSUInteger)_index {}
- (())drawPrimitives:(NSUInteger)_type vertexStart:(NSUInteger)_start vertexCount:(NSUInteger)_count {}
- (())drawIndexedPrimitives:(NSUInteger)_type indexCount:(NSUInteger)_count indexType:(NSUInteger)_index_type indexBuffer:(id)_buffer indexBufferOffset:(NSUInteger)_offset {}
@end

@implementation MTLRenderPassDescriptor: NSObject
+ (id)renderPassDescriptor { msg_class![env; MTLRenderPassDescriptor new] }
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (id)colorAttachments { msg_class![env; MTLRenderPassColorAttachmentDescriptorArray new] }
- (id)depthAttachment { msg_class![env; MTLRenderPassDepthAttachmentDescriptor new] }
- (id)stencilAttachment { msg_class![env; MTLRenderPassStencilAttachmentDescriptor new] }
@end

@implementation MTLRenderPassColorAttachmentDescriptorArray: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (id)objectAtIndexedSubscript:(NSUInteger)index {
    if (index as usize) >= MAX_COLOR_ATTACHMENTS {
        return msg_class![env; MTLRenderPassColorAttachmentDescriptor new];
    }
    let stored = env.objc.borrow::<MetalObjectHostObject>(this).color_attachments[index as usize];
    if stored != nil {
        return stored;
    }
    let attachment = msg_class![env; MTLRenderPassColorAttachmentDescriptor new];
    env.objc.borrow_mut::<MetalObjectHostObject>(this).color_attachments[index as usize] = attachment;
    attachment
}
- (id)objectAtIndex:(NSUInteger)index { msg![env; this objectAtIndexedSubscript:index] }
- (())setObject:(id)obj atIndexedSubscript:(NSUInteger)index {
    if (index as usize) < MAX_COLOR_ATTACHMENTS {
        env.objc.borrow_mut::<MetalObjectHostObject>(this).color_attachments[index as usize] = obj;
    }
}
@end

@implementation MTLRenderPassColorAttachmentDescriptor: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (())setTexture:(id)texture { env.objc.borrow_mut::<MetalObjectHostObject>(this).device = texture }
- (id)texture { env.objc.borrow::<MetalObjectHostObject>(this).device }
- (())setLoadAction:(NSUInteger)action { env.objc.borrow_mut::<MetalObjectHostObject>(this).load_action = action }
- (NSUInteger)loadAction { env.objc.borrow::<MetalObjectHostObject>(this).load_action }
- (())setStoreAction:(NSUInteger)action { env.objc.borrow_mut::<MetalObjectHostObject>(this).store_action = action }
- (NSUInteger)storeAction { env.objc.borrow::<MetalObjectHostObject>(this).store_action }
- (())setClearColor:(id)color {
    let host = env.objc.borrow_mut::<MetalObjectHostObject>(this);
    for component in 0usize..4 {
        let value: f64 = if color == nil {
            0.0
        } else {
            env.mem.read(color.cast::<f64>() + component as u32)
        };
        host.clear_color[component] = value;
    }
}
- (id)clearColor { nil }
- (())setResolveTexture:(id)texture { env.objc.borrow_mut::<MetalObjectHostObject>(this).device = texture }
- (id)resolveTexture { env.objc.borrow::<MetalObjectHostObject>(this).device }
@end

@implementation MTLTexture: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (id)device { env.objc.borrow::<MetalObjectHostObject>(this).device }
- (NSUInteger)width { env.objc.borrow::<MetalObjectHostObject>(this).width }
- (NSUInteger)height { env.objc.borrow::<MetalObjectHostObject>(this).height }
- (NSUInteger)depth { env.objc.borrow::<MetalObjectHostObject>(this).depth }
- (NSUInteger)mipmapLevelCount { env.objc.borrow::<MetalObjectHostObject>(this).mipmap_level_count }
- (NSUInteger)sampleCount { env.objc.borrow::<MetalObjectHostObject>(this).sample_count }
- (NSUInteger)pixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).pixel_format }
- (())replaceRegion:(id)_region mipmapLevel:(NSUInteger)_level withBytes:(ConstVoidPtr)_bytes bytesPerRow:(NSUInteger)_row {}
@end

@implementation MTLBuffer: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone {
    env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem)
}
- (id)device { env.objc.borrow::<MetalObjectHostObject>(this).device }
- (NSUInteger)length { env.objc.borrow::<MetalObjectHostObject>(this).length }
- (MutVoidPtr)contents { env.objc.borrow::<MetalObjectHostObject>(this).contents }
- (NSUInteger)storageMode { env.objc.borrow::<MetalObjectHostObject>(this).storage_mode }
@end

@implementation MTLRenderPipelineState: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (id)device { env.objc.borrow::<MetalObjectHostObject>(this).device }
@end

@implementation MTLDepthStencilState: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
@end

@implementation MTLLibrary: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (id)init { this }
- (id)label { env.objc.borrow::<MetalObjectHostObject>(this).label }
- (())setLabel:(id)label { env.objc.borrow_mut::<MetalObjectHostObject>(this).label = label }
- (id)newFunctionWithName:(id)name {
    let object = msg_class![env; MTLFunction new];
    env.objc.borrow_mut::<MetalObjectHostObject>(object).label = name;
    object
}
@end

@implementation MTLFunction: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (id)init { this }
- (id)name { env.objc.borrow::<MetalObjectHostObject>(this).label }
- (id)label { env.objc.borrow::<MetalObjectHostObject>(this).label }
- (())setLabel:(id)label { env.objc.borrow_mut::<MetalObjectHostObject>(this).label = label }
- (id)vertexFunction { env.objc.borrow::<MetalObjectHostObject>(this).vertex_function }
- (())setVertexFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).vertex_function = function }
- (id)fragmentFunction { env.objc.borrow::<MetalObjectHostObject>(this).fragment_function }
- (())setFragmentFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).fragment_function = function }
- (NSUInteger)depthAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).depth_pixel_format }
- (())setDepthAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).depth_pixel_format = format }
- (NSUInteger)stencilAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).stencil_pixel_format }
- (())setStencilAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).stencil_pixel_format = format }
@end

@implementation MTLRenderPipelineColorAttachmentDescriptor: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (NSUInteger)pixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).pixel_format }
- (())setPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).pixel_format = format }
- (bool)blendingEnabled { env.objc.borrow::<MetalObjectHostObject>(this).blending_enabled }
- (())setBlendingEnabled:(bool)enabled { env.objc.borrow_mut::<MetalObjectHostObject>(this).blending_enabled = enabled }
- (NSUInteger)sourceRGBBlendFactor { env.objc.borrow::<MetalObjectHostObject>(this).source_rgb_blend_factor }
- (())setSourceRGBBlendFactor:(NSUInteger)factor { env.objc.borrow_mut::<MetalObjectHostObject>(this).source_rgb_blend_factor = factor }
- (NSUInteger)destinationRGBBlendFactor { env.objc.borrow::<MetalObjectHostObject>(this).destination_rgb_blend_factor }
- (())setDestinationRGBBlendFactor:(NSUInteger)factor { env.objc.borrow_mut::<MetalObjectHostObject>(this).destination_rgb_blend_factor = factor }
- (NSUInteger)sourceAlphaBlendFactor { env.objc.borrow::<MetalObjectHostObject>(this).source_alpha_blend_factor }
- (())setSourceAlphaBlendFactor:(NSUInteger)factor { env.objc.borrow_mut::<MetalObjectHostObject>(this).source_alpha_blend_factor = factor }
- (NSUInteger)destinationAlphaBlendFactor { env.objc.borrow::<MetalObjectHostObject>(this).destination_alpha_blend_factor }
- (())setDestinationAlphaBlendFactor:(NSUInteger)factor { env.objc.borrow_mut::<MetalObjectHostObject>(this).destination_alpha_blend_factor = factor }
- (NSUInteger)rgbBlendOperation { env.objc.borrow::<MetalObjectHostObject>(this).rgb_blend_operation }
- (())setRgbBlendOperation:(NSUInteger)operation { env.objc.borrow_mut::<MetalObjectHostObject>(this).rgb_blend_operation = operation }
- (NSUInteger)alphaBlendOperation { env.objc.borrow::<MetalObjectHostObject>(this).alpha_blend_operation }
- (())setAlphaBlendOperation:(NSUInteger)operation { env.objc.borrow_mut::<MetalObjectHostObject>(this).alpha_blend_operation = operation }
- (id)fragmentFunction { env.objc.borrow::<MetalObjectHostObject>(this).fragment_function }
- (())setFragmentFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).fragment_function = function }
- (NSUInteger)depthAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).depth_pixel_format }
- (())setDepthAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).depth_pixel_format = format }
- (NSUInteger)stencilAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).stencil_pixel_format }
- (())setStencilAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).stencil_pixel_format = format }
@end

@implementation MTLDepthStencilDescriptor: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (id)init { this }
- (NSUInteger)depthCompareFunction { env.objc.borrow::<MetalObjectHostObject>(this).usage }
- (())setDepthCompareFunction:(NSUInteger)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).usage = function }
- (bool)depthWriteEnabled { env.objc.borrow::<MetalObjectHostObject>(this).sample_count != 0 }
- (())setDepthWriteEnabled:(bool)enabled { env.objc.borrow_mut::<MetalObjectHostObject>(this).sample_count = enabled as NSUInteger }
- (id)frontFaceStencil {
    let existing = env.objc.borrow::<MetalObjectHostObject>(this).front_stencil;
    if existing != nil { return existing; }
    let stencil = msg_class![env; MTLStencilDescriptor new];
    env.objc.borrow_mut::<MetalObjectHostObject>(this).front_stencil = stencil;
    stencil
}
- (id)backFaceStencil {
    let existing = env.objc.borrow::<MetalObjectHostObject>(this).back_stencil;
    if existing != nil { return existing; }
    let stencil = msg_class![env; MTLStencilDescriptor new];
    env.objc.borrow_mut::<MetalObjectHostObject>(this).back_stencil = stencil;
    stencil
}
- (id)label { env.objc.borrow::<MetalObjectHostObject>(this).label }
- (())setLabel:(id)label { env.objc.borrow_mut::<MetalObjectHostObject>(this).label = label }
- (id)vertexFunction { env.objc.borrow::<MetalObjectHostObject>(this).vertex_function }
- (())setVertexFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).vertex_function = function }
- (id)fragmentFunction { env.objc.borrow::<MetalObjectHostObject>(this).fragment_function }
- (())setFragmentFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).fragment_function = function }
- (NSUInteger)depthAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).depth_pixel_format }
- (())setDepthAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).depth_pixel_format = format }
- (NSUInteger)stencilAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).stencil_pixel_format }
- (())setStencilAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).stencil_pixel_format = format }
@end


@implementation MTLStencilDescriptor: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (id)init { this }
- (NSUInteger)stencilCompareFunction { env.objc.borrow::<MetalObjectHostObject>(this).stencil_compare_function }
- (())setStencilCompareFunction:(NSUInteger)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).stencil_compare_function = function }
- (NSUInteger)stencilFailureOperation { env.objc.borrow::<MetalObjectHostObject>(this).stencil_failure_operation }
- (())setStencilFailureOperation:(NSUInteger)operation { env.objc.borrow_mut::<MetalObjectHostObject>(this).stencil_failure_operation = operation }
- (NSUInteger)depthFailureOperation { env.objc.borrow::<MetalObjectHostObject>(this).depth_failure_operation }
- (())setDepthFailureOperation:(NSUInteger)operation { env.objc.borrow_mut::<MetalObjectHostObject>(this).depth_failure_operation = operation }
- (NSUInteger)depthStencilPassOperation { env.objc.borrow::<MetalObjectHostObject>(this).depth_stencil_pass_operation }
- (())setDepthStencilPassOperation:(NSUInteger)operation { env.objc.borrow_mut::<MetalObjectHostObject>(this).depth_stencil_pass_operation = operation }
- (NSUInteger)writeMask { env.objc.borrow::<MetalObjectHostObject>(this).write_mask }
- (())setWriteMask:(NSUInteger)mask { env.objc.borrow_mut::<MetalObjectHostObject>(this).write_mask = mask }
- (NSUInteger)readMask { env.objc.borrow::<MetalObjectHostObject>(this).read_mask }
- (())setReadMask:(NSUInteger)mask { env.objc.borrow_mut::<MetalObjectHostObject>(this).read_mask = mask }
@end

@implementation MTLRenderPipelineDescriptor: NSObject
+ (id)allocWithZone:(NSZonePtr)_zone { env.objc.alloc_object(this, Box::new(MetalObjectHostObject::default()), &mut env.mem) }
- (id)init { this }
- (id)vertexDescriptor { env.objc.borrow::<MetalObjectHostObject>(this).layouts }
- (())setVertexDescriptor:(id)descriptor { env.objc.borrow_mut::<MetalObjectHostObject>(this).layouts = descriptor }
- (id)colorAttachments { msg_class![env; MTLRenderPassColorAttachmentDescriptorArray new] }
- (NSUInteger)sampleCount { env.objc.borrow::<MetalObjectHostObject>(this).sample_count }
- (())setSampleCount:(NSUInteger)count { env.objc.borrow_mut::<MetalObjectHostObject>(this).sample_count = count }
- (id)label { env.objc.borrow::<MetalObjectHostObject>(this).label }
- (())setLabel:(id)label { env.objc.borrow_mut::<MetalObjectHostObject>(this).label = label }
- (id)vertexFunction { env.objc.borrow::<MetalObjectHostObject>(this).vertex_function }
- (())setVertexFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).vertex_function = function }
- (id)fragmentFunction { env.objc.borrow::<MetalObjectHostObject>(this).fragment_function }
- (())setFragmentFunction:(id)function { env.objc.borrow_mut::<MetalObjectHostObject>(this).fragment_function = function }
- (NSUInteger)depthAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).depth_pixel_format }
- (())setDepthAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).depth_pixel_format = format }
- (NSUInteger)stencilAttachmentPixelFormat { env.objc.borrow::<MetalObjectHostObject>(this).stencil_pixel_format }
- (())setStencilAttachmentPixelFormat:(NSUInteger)format { env.objc.borrow_mut::<MetalObjectHostObject>(this).stencil_pixel_format = format }
@end



};

fn MTLCreateSystemDefaultDevice(env: &mut Environment) -> id {
    msg_class![env; MTLDevice new]
}

pub const FUNCTIONS: crate::dyld::FunctionExports =
    &[crate::dyld::export_c_func!(MTLCreateSystemDefaultDevice())];

pub const CONSTANTS: ConstantExports = &[
    (
        "_MTLResourceStorageModeShared",
        crate::dyld::HostConstant::Custom(|env| {
            constant_uinteger(env, MTL_RESOURCE_STORAGE_MODE_SHARED)
        }),
    ),
    (
        "_MTLResourceStorageModeManaged",
        crate::dyld::HostConstant::Custom(|env| {
            constant_uinteger(env, MTL_RESOURCE_STORAGE_MODE_MANAGED)
        }),
    ),
    (
        "_MTLResourceStorageModePrivate",
        crate::dyld::HostConstant::Custom(|env| {
            constant_uinteger(env, MTL_RESOURCE_STORAGE_MODE_PRIVATE)
        }),
    ),
    (
        "_MTLResourceStorageModeMemoryless",
        crate::dyld::HostConstant::Custom(|env| {
            constant_uinteger(env, MTL_RESOURCE_STORAGE_MODE_MEMORYLESS)
        }),
    ),
    (
        "_MTLLoadActionDontCare",
        crate::dyld::HostConstant::Custom(|env| constant_uinteger(env, MTL_LOAD_ACTION_DONT_CARE)),
    ),
    (
        "_MTLLoadActionLoad",
        crate::dyld::HostConstant::Custom(|env| constant_uinteger(env, MTL_LOAD_ACTION_LOAD)),
    ),
    (
        "_MTLLoadActionClear",
        crate::dyld::HostConstant::Custom(|env| constant_uinteger(env, MTL_LOAD_ACTION_CLEAR)),
    ),
    (
        "_MTLStoreActionDontCare",
        crate::dyld::HostConstant::Custom(|env| constant_uinteger(env, MTL_STORE_ACTION_DONT_CARE)),
    ),
    (
        "_MTLStoreActionStore",
        crate::dyld::HostConstant::Custom(|env| constant_uinteger(env, MTL_STORE_ACTION_STORE)),
    ),
];
