/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
//! `UIControl`.
//!
//! Useful resources:
//! - The [Target-Action section](https://developer.apple.com/library/archive/documentation/General/Conceptual/CocoaEncyclopedia/Target-Action/Target-Action.html) of Apple's "Concepts in Objective-C Programming".

pub mod ui_bar_button_item;
pub mod ui_button;
pub mod ui_segmented_control;
pub mod ui_slider;
pub mod ui_switch;
pub mod ui_text_field;

use crate::frameworks::core_graphics::CGPoint;
use crate::frameworks::foundation::{NSInteger, NSUInteger};
use crate::frameworks::uikit::ui_application;
use crate::objc::{
    id, impl_HostObject_with_superclass, msg, msg_class, msg_send, msg_super, nil, objc_classes,
    release, retain, ClassExports, NSZonePtr, SEL,
};
use crate::Environment;

pub type UIControlEvents = NSUInteger;
pub const UIControlEventTouchDown: UIControlEvents = 1 << 0;
const UIControlEventTouchDownRepeat: UIControlEvents = 1 << 1;
const UIControlEventTouchDragInside: UIControlEvents = 1 << 2;
const UIControlEventTouchDragOutside: UIControlEvents = 1 << 3;
const UIControlEventTouchDragEnter: UIControlEvents = 1 << 4;
pub const UIControlEventTouchDragExit: UIControlEvents = 1 << 5;
pub const UIControlEventTouchUpInside: UIControlEvents = 1 << 6;
pub const UIControlEventTouchUpOutside: UIControlEvents = 1 << 7;
pub const UIControlEventTouchCancel: UIControlEvents = 1 << 8;
pub const UIControlEventValueChanged: UIControlEvents = 1 << 12;
pub const UIControlEventEditingDidBegin: UIControlEvents = 1 << 16;
pub const UIControlEventEditingChanged: UIControlEvents = 1 << 17;
pub const UIControlEventEditingDidEnd: UIControlEvents = 1 << 18;
const UIControlEventEditingDidEndOnExit: UIControlEvents = 1 << 19;

pub type UIControlContentVerticalAlignment = NSInteger;
const UIControlContentVerticalAlignmentCenter: UIControlContentVerticalAlignment = 0;

pub struct UIControlHostObject {
    superclass: super::UIViewHostObject,
    enabled: bool,
    selected: bool,
    highlighted: bool,
    content_vertical_alignment: UIControlContentVerticalAlignment,
    /// `UITouch*` of the touch currently being tracked, [nil] if none
    tracked_touch: id,
    tracking: bool,
    /// See `addTarget:action:forControlEvents:`. The target is a weak
    /// reference!
    action_targets: Vec<(id, SEL, UIControlEvents)>,
}
impl_HostObject_with_superclass!(UIControlHostObject);
impl Default for UIControlHostObject {
    fn default() -> Self {
        UIControlHostObject {
            superclass: Default::default(),
            enabled: true,
            selected: false,
            highlighted: false,
            content_vertical_alignment: UIControlContentVerticalAlignmentCenter,
            tracked_touch: nil,
            tracking: false,
            action_targets: Vec::new(),
        }
    }
}

type UIControlState = NSUInteger;
pub const UIControlStateNormal: UIControlState = 0;
const UIControlStateHighlighted: UIControlState = 1 << 0;
const UIControlStateDisabled: UIControlState = 1 << 1;
const UIControlStateSelected: UIControlState = 1 << 2;
#[allow(dead_code)]
const UIControlStateFocused: UIControlState = 1 << 3;

fn send_actions(env: &mut Environment, this: id, event: id, control_event: UIControlEvents) {
    let UIControlHostObject { action_targets, .. } = env.objc.borrow(this);
    let action_targets: Vec<_> = action_targets
        .iter()
        .filter(|&(_target, _action, for_control_events)| (for_control_events & control_event) != 0)
        .map(|&(target, action, _for_control_events)| (target, action))
        .collect();

    if !action_targets.is_empty() {
        log!(
            "UIControl {:?} dispatching {} action(s) for control event mask {:#x}",
            this,
            action_targets.len(),
            control_event,
        );
    }

    let application: id = msg_class![env; UIApplication sharedApplication];
    for (target, action) in action_targets {
        () = msg![env; application sendAction:action to:target from:this forEvent:event];
    }
}

pub const CLASSES: ClassExports = objc_classes! {

(env, this, _cmd);

// abstract class
@implementation UIControl: UIView

+ (id)allocWithZone:(NSZonePtr)_zone {
    let host_object = Box::<UIControlHostObject>::default();
    env.objc.alloc_object(this, host_object, &mut env.mem)
}

- (())dealloc {
    let UIControlHostObject {
        superclass: _,
        enabled: _,
        selected: _,
        highlighted: _,
        content_vertical_alignment: _,
        tracking: _,
        action_targets: _, // targets are weak references, nothing to do
        tracked_touch,
    } = std::mem::take(env.objc.borrow_mut(this));

    release(env, tracked_touch);

    msg_super![env; this dealloc]
}

- (UIControlState)state {
    let &UIControlHostObject {
        highlighted,
        enabled,
        selected,
        ..
    } = env.objc.borrow(this);
    // TODO: focussed
    let mut state = 0; // aka UIControlStateNormal
    if highlighted {
        state |= UIControlStateHighlighted;
    }
    if !enabled {
        state |= UIControlStateDisabled;
    }
    if selected {
        state |= UIControlStateSelected;
    }
    state
}

- (bool)isEnabled {
    env.objc.borrow::<UIControlHostObject>(this).enabled
}
- (())setEnabled:(bool)enabled {
    env.objc.borrow_mut::<UIControlHostObject>(this).enabled = enabled;
}

- (bool)isSelected {
    env.objc.borrow::<UIControlHostObject>(this).selected
}
- (())setSelected:(bool)selected {
    env.objc.borrow_mut::<UIControlHostObject>(this).selected = selected;
}

- (bool)isHighlighted {
    env.objc.borrow::<UIControlHostObject>(this).highlighted
}
- (())setHighlighted:(bool)highlighted {
    env.objc.borrow_mut::<UIControlHostObject>(this).highlighted = highlighted;
}

- (NSInteger)contentVerticalAlignment {
    env.objc.borrow::<UIControlHostObject>(this).content_vertical_alignment
}

- (())setContentVerticalAlignment:(UIControlContentVerticalAlignment)alignment {
    env.objc.borrow_mut::<UIControlHostObject>(this).content_vertical_alignment = alignment;
}

- (bool)tracking {
    env.objc.borrow::<UIControlHostObject>(this).tracking
}

- (())cancelTrackingWithEvent:(id)_event {
    // default implementation, subclasses can override this
}

- (bool)beginTrackingWithTouch:(id)_touch // UITouch*
                     withEvent:(id)_event { // UIEvent*
    // default implementation, subclasses can override this
    true
}
- (bool)continueTrackingWithTouch:(id)_touch // UITouch*
                        withEvent:(id)_event { // UIEvent*
    // default implementation, subclasses can override this
    true
}
- (())endTrackingWithTouch:(id)_touch // UITouch*
                  withEvent:(id)_event { // UIEvent*
    // default implementation, subclasses can override this, must call super
    // (for some reason, the docs say this default implementation updates the
    // tracking property? why here?)
    env.objc.borrow_mut::<UIControlHostObject>(this).tracking = false;
}

- (())touchesBegan:(id)touches // NSSet* of UITouch*
         withEvent:(id)event { // UIEvent*
    if !msg![env; this isEnabled] {
        return;
    }

    // UIControl's documentation implies that only one touch is ever tracked
    // at once.
    let touch: id = msg![env; touches anyObject];
    if !msg![env; this beginTrackingWithTouch:touch withEvent:event] {
        return;
    }

    retain(env, touch);
    let host_obj = env.objc.borrow_mut::<UIControlHostObject>(this);
    host_obj.tracking = true;
    let old_touch = std::mem::replace(&mut host_obj.tracked_touch, touch);
    release(env, old_touch);
    if old_touch != nil {
        log!("Got new touch {:?} but old touch {:?} has not yet ended!", touch, old_touch);
    }
    // Not sure if this is the right place to set this.
    () = msg![env; this setHighlighted:true];

    // TODO: unclear if this is meant to be affected by tracking
    send_actions(env, this, event, UIControlEventTouchDown);
}
- (())touchesMoved:(id)touches // NSSet* of UITouch*
         withEvent:(id)event { // UIEvent*
    if !msg![env; this isEnabled] {
        return;
    }

    let touch: id = msg![env; touches anyObject];
    let tracked_touch = env.objc.borrow::<UIControlHostObject>(this).tracked_touch;
    if tracked_touch != touch {
        return;
    }
    if !msg![env; this continueTrackingWithTouch:touch withEvent:event] {
        release(env, tracked_touch);
        env.objc.borrow_mut::<UIControlHostObject>(this).tracked_touch = nil;
        env.objc.borrow_mut::<UIControlHostObject>(this).tracking = false;
        () = msg![env; this setHighlighted:false];
    }

    let old_pos: CGPoint = msg![env; touch previousLocationInView:this];
    let new_pos: CGPoint = msg![env; touch locationInView:this];
    let was_inside = msg![env; this pointInside:old_pos withEvent:event];
    let is_inside = msg![env; this pointInside:new_pos withEvent:event];

    // TODO: unclear if this is meant to be affected by tracking
    send_actions(env, this, event, match (was_inside, is_inside) {
        (true, true) => UIControlEventTouchDragInside,
        (false, false) => UIControlEventTouchDragOutside,
        (false, true) => UIControlEventTouchDragEnter,
        (true, false) => UIControlEventTouchDragExit,
    });
}
- (())touchesEnded:(id)touches // NSSet* of UITouch*
         withEvent:(id)event { // UIEvent*
    let touch: id = msg![env; touches anyObject];
    let tracked_touch = env.objc.borrow::<UIControlHostObject>(this).tracked_touch;
    if tracked_touch != touch {
        return;
    }
    () = msg![env; this endTrackingWithTouch:touch withEvent:event];
    release(env, tracked_touch);
    env.objc.borrow_mut::<UIControlHostObject>(this).tracked_touch = nil;
    () = msg![env; this setHighlighted:false];

    let new_pos: CGPoint = msg![env; touch locationInView:this];
    let is_inside = msg![env; this pointInside:new_pos withEvent:event];

    // TODO: unclear if this is meant to be affected by tracking
    send_actions(env, this, event, match is_inside {
        true => UIControlEventTouchUpInside,
        false => UIControlEventTouchUpOutside,
    });
}

- (())touchesCancelled:(id)touches withEvent:(id)event {
    let tracked = env.objc.borrow::<UIControlHostObject>(this).tracked_touch;
    if tracked == nil { return; }
    let contains: bool = msg![env; touches containsObject:tracked];
    if !contains { return; }
    let host = env.objc.borrow_mut::<UIControlHostObject>(this);
    host.tracked_touch = nil;
    host.tracking = false;
    () = msg![env; this cancelTrackingWithEvent:event];
    () = msg![env; this setHighlighted:false];
    send_actions(env, this, event, UIControlEventTouchCancel);
    release(env, tracked);
}

- (())addTarget:(id)target
         action:(SEL)action
forControlEvents:(UIControlEvents)events {
    // A nil target is intentional: UIApplication resolves the action through
    // the sender's responder chain when the control event is delivered.
    // The target is a *weak* reference!

    // The selector must be for a method with zero to two arguments. A
    // selector with more colons is malformed guest input; log it and ignore
    // the registration instead of panicking the host.
    let sel_str = action.as_str(&env.mem);
    let colon_count = sel_str.bytes().filter(|&b| b == b':').count();
    if ![0, 1, 2].contains(&colon_count) {
        log!(
            "Warning: addTarget: unsupported selector {:?} ({} colons); ignoring.",
            sel_str, colon_count
        );
        return;
    }

    env.objc.borrow_mut::<UIControlHostObject>(this).action_targets.push((target, action, events));
}

- (())sendAction:(SEL)action
              to:(id)target
        forEvent:(id)event { // UIEvent*
    let sel_str = action.as_str(&env.mem);
    let colon_count = sel_str.bytes().filter(|&b| b == b':').count();
    match colon_count {
        // - (IBAction)action;
        0 => {
            log_dbg!(
                "Sending {:?} ({:?}) message to {:?} (no args)",
                action,
                sel_str,
                target
            );
            () = msg_send(env, (target, action));
        }
        // - (IBAction)action:(id)sender;
        1 => {
            log_dbg!(
                "Sending {:?} ({:?}) message to {:?} (one arg: {:?})",
                action,
                sel_str,
                target,
                this
            );
            () = msg_send(env, (target, action, this));
        }
        // - (IBAction)action:(id)sender forEvent:(UIEvent*)event;
        2 => {
            log_dbg!(
                "Sending {:?} ({:?}) message to {:?} (two args: {:?}, {:?})",
                action,
                sel_str,
                target,
                this,
                event
            );
            () = msg_send(env, (target, action, this, event));
        }
        other => {
            // UIControl actions have 0, 1 or 2 explicit arguments (plus self
            // and the selector). Anything else is a malformed selector; on
            // real UIKit Objective-C would just `objc_msgSend` the call and
            // garble the arguments. Logging is safer than crashing the host
            // when an end-of-life iOS app registers an unusual selector.
            log!(
                "Warning: UIControl::send_actions: unsupported argument count {} for {:?}; skipping.",
                other,
                sel_str
            );
        }
    };
}

- (())removeTarget:(id)target
            action:(SEL)action
  forControlEvents:(UIControlEvents)events {
    let action_targets = &mut env.objc.borrow_mut::<UIControlHostObject>(this).action_targets;
    action_targets.retain(|(t, a, e)| {
        // If target is nil, match any target; otherwise only the specified one.
        let target_match = target == crate::objc::nil || *t == target;
        // If action selector is null/zero, match any action; otherwise only
        // the specified one.
        let action_match = action.is_null() || *a == action;
        // Only remove entries where events overlap.
        let events_match = (*e & events) != 0;
        // Retain entries that do NOT match all three conditions.
        !(target_match && action_match && events_match)
    });
}

// TODO: more triggers/targets/actions stuff

@end

};
